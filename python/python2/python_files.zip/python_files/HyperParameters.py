'''
Created on Sep 24, 2020

@author: Michael Pradel
'''

name_embedding_size = 200
file_name_embedding_size = 50
type_embedding_size = 5
node_type_embedding_size = 8
